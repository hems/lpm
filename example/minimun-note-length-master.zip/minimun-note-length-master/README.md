HERMMUTT LOBBY's Minimun Note Length js 0.1

Description :
-------------
The Minimun Note length is a max4live tool created to set a minimun length for
a midi note.


Usage :
-------
Tweak the knob to the desired ammount of time, so far time is in ms.

Todo :
------

* SKIN the interface
* interface to keep the length synced to 1xbeat, 2xbeat, 0.5xbeat etcs

Changelog :
-----------

0.1 :
* Initial tested release